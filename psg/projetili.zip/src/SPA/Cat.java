package SPA;

public class Cat extends Animaux {

	public Cat(String nom, float prize,int size, double height) {
		super(nom, prize, size, height);
	}
}