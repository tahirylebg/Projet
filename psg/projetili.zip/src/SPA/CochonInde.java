package SPA;

public class CochonInde extends Animaux{

	public CochonInde(String nom, float prize, int size, double height) {
		super(nom, prize, size, height);
	}

}
