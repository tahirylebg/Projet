package SPA;

public class Ouaf extends Animaux{

	public Ouaf(String nom, float prize, int size, double height) {
		super(nom, prize, size, height);
		// TODO Auto-generated constructor stub
	}

}
